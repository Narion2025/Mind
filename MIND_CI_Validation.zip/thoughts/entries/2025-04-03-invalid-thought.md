---
title: Missing required fields
date: 2025-04-03
# Missing 'author', 'context', and 'topics'
---
Dies ist ein absichtlich unvollständiger Gedanke zum Testen der Validierung.
